You are able to add a payment mode directly on a partner.

This payment mode is automatically associated to the invoice related to the
partner. This default value could be changed in a draft invoice.

When you create a payment order, only invoices related to chosen payment mode
are displayed.

Invoices without any payment mode are displayed too.
