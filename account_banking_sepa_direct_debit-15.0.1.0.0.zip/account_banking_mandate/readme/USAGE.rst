To use this module, see menu "Invoicing/Accounting > Customers > Debit Orders"
