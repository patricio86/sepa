This module depends on :
* account_payment

This module is part of the OCA/bank-payment suite.
