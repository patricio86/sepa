This module depends on :

* account_banking_pain_base
* account_banking_mandate

This module is part of the OCA/bank-payment suite.
