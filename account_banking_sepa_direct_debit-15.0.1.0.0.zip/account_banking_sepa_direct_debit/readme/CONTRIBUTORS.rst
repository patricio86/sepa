* Alexis de Lattre <alexis.delattre@akretion.com>
* Stéphane Bidoul <stephane.bidoul@acsone.eu>
* Alexandre Fayolle
* Raphaël Valyi
* Sandy Carter
* Antonio Espinosa <antonioea@antiun.com>
* Marçal Isern <marsal.isern@qubiq.es>
* `Tecnativa <https://www.tecnativa.com>`__:

  * Pedro M. Baeza
  * Sergio Teruel
  * Carlos Roca
* Manuel Regidor <manuel.regidor@sygel.es>
