from . import res_company
from . import account_banking_mandate
from . import bank_payment_line
from . import account_payment_mode
from . import account_payment_method
from . import account_payment_order
from . import account_payment_line
