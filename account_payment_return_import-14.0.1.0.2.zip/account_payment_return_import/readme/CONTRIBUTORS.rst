* Thomas Binsfeld <thomas.binsfeld@acsone.eu>
* `Tecnativa <https://www.tecnativa.com>`_:

  * Carlos Dauden
  * Pedro M. Baeza
  * David Vidal
  * Luis M. Ontalba
  * Ernesto Tejeda
