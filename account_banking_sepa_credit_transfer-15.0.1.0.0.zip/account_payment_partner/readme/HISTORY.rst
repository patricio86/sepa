10.0.1.2.0 (2018-05-24)
~~~~~~~~~~~~~~~~~~~~~~~

* [IMP] Add options to show partner bank account in invoice report
  (`#458 <https://github.com/OCA/bank-payment/issues/458>`_)
