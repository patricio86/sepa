* Alexis de Lattre <alexis.delattre@akretion.com>
* Stéphane Bidoul <stephane.bidoul@acsone.eu>
* Stefan Rijnhart
* Julien Laloux
* Alexandre Fayolle
* Raphaël Valyi
* Erwin van der Ploeg
* Sandy Carter
* `Tecnativa <https://www.tecnativa.com>`__:

  * Antonio Espinosa
  * Pedro M. Baeza
  * Carlos Roca
* `DynApps NV <https://www.dynapps.be>`_:

  * Axel Priem <axel.priem@dynapps.be>
* `Sygel Technology <https://www.sygel.es>`_:

  * Valentin Vinagre <valentin.vinagre@sygel.es>
  * Manuel Regidor <manuel.regidor@sygel.es>
