You can create a Payment order via the menu Invoicing/Accounting > Vendors > Payment Orders and then select the move lines to pay.

You can create a Debit order via the menu Invoicing/Accounting > Customers > Debit Orders and then select the move lines to debit.

This module also adds an action *Add to Payment Order* on supplier invoices and *Add to Debit Order* on customer invoices.

You can print a Payment order via the menu Invoicing/Accounting > Vendors > Payment Orders and then select the payment oder to print.
