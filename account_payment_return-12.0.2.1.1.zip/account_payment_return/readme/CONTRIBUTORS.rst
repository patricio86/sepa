* 7 i TRIA <http://www.7itria.cat>
* Avanzosc <http://www.avanzosc.com>
* Pedro M. Baeza <pedro.baeza@tecnativa.com>
* Markus Schneider <markus.schneider@initos.com>
* Sergio Teruel <sergio.teruel@tecnativa.com>
* Carlos Dauden <carlos.dauden@tecnativa.com>
* David Vidal <david.vidal@tecnativa.com>
* Luis M. Ontalba <luis.martinez@tecnativa.com>
